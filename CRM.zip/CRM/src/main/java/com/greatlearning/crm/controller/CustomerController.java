package com.greatlearning.crm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.greatlearning.crm.entity.Customer;
import com.greatlearning.crm.service.CustomerService;

@Controller
@RequestMapping("/books")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	// add mapping for "/list"

	@RequestMapping("/list")
	public String listBooks(Model theModel) {

		// get Books from db
		List<Customer> theBooks = customerService.findAll();

		// add to the spring model
		theModel.addAttribute("Customers", theBooks);

		return "list-Books";
	}

	@RequestMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {

		// create model attribute to bind form data
		Customer theBook = new Customer();

		theModel.addAttribute("Customer", theBook);

		return "Book-form";
	}

	@RequestMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("bookId") int theId, Model theModel) {

		// get the Book from the service
		Customer theBook = customerService.findById(theId);

		// set Book as a model attribute to pre-populate the form
		theModel.addAttribute("Customer", theBook);

		// send over to our form
		return "Book-form";
	}

	@PostMapping("/save")
	public String saveBook(@RequestParam("id") int id,
			@RequestParam("fname") String fname,
			@RequestParam("lname") String lname, 
			@RequestParam("email") String email) {

		System.out.println(id + fname);
		Customer theBook;
		if (id != 0) {
			theBook = customerService.findById(id);
			theBook.setFname(fname);
			theBook.setLname(lname);
			theBook.setEmail(email);
		} else
			theBook = new Customer(fname, lname, email);
		// save the Book
		customerService.save(theBook);

		// use a redirect to prevent duplicate submissions
		return "redirect:/books/list";

	}

	@RequestMapping("/delete")
	public String delete(@RequestParam("bookId") int theId) {

		// delete the Book
		System.out.println("book id:" + theId);
		customerService.deleteById(theId);

		// redirect to /Books/list
		return "redirect:/books/list";

	}

	@RequestMapping("/search")
	public String search(@RequestParam("fname") String fname, 
			@RequestParam("email") String email, Model theModel) {

		// check names, if both are empty then just give list of all customer

		if (fname.trim().isEmpty() && email.trim().isEmpty()) {
			return "redirect:/books/list";
		} else {
			// else, search by first name and email
			List<Customer> theBooks = customerService.searchBy(fname, email);

			// add to the spring model
			theModel.addAttribute("Customers", theBooks);

			// send to list-Books
			return "list-Books";
		}

	}
}
